package si.um.feri.jee.sample;


import javax.jms.*;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Properties;

public class JMSMain {

    public static void main(String[] args) throws NamingException, JMSException {
        System.out.println("LMAO");
        Properties props=new Properties();
        props.put("java.naming.factory.initial","org.jboss.naming.remote.client.InitialContextFactory");
        props.put("java.naming.provider.url","http-remoting://127.0.0.1:8080");
        InitialContext ictx = new InitialContext(props);

        Queue queue = (Queue) ictx.lookup("jms/queue/test");
        Destination destination = queue;

        ConnectionFactory factory = (ConnectionFactory) ictx.lookup("jms/RemoteConnectionFactory");
        JMSContext ctx=factory.createContext();
        JMSProducer producer=ctx.createProducer();

        MapMessage message = ctx.createMapMessage();
        message.setStringProperty("zdravnikEmail", "Boric.Kovacic@lmao.lmao");
        message.setStringProperty("pacientEmail", "Janez.Novak@lmao.lmao");

        producer.send(destination, message);
        System.out.println("Message sent.");
    }
}
