package si.um.feri.jee.sample;

import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;
import si.um.feri.jee.sample.vao.Pacient;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDate;


public class restMain {

    static final URI osebe_URI = URI.create("http://localhost:8080/AIV/api/pacienti");
    HttpClient client = HttpClient.newBuilder().build();
    Jsonb jsonb = JsonbBuilder.create();
    void vseOsebe() throws Exception {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(osebe_URI)
                .GET()
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println(response.body());
    }

    void dodajOsebo(Pacient pacient) throws Exception{
        HttpRequest request = HttpRequest.newBuilder()
                .POST(HttpRequest.BodyPublishers.ofString(jsonb.toJson(pacient)))
                .header("Content-Type","\tapplication/json")
                .uri(osebe_URI)
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println(response.body());
    }

    void dodajZdravnika(String pacientEmail, String zdravnikEmail) throws Exception{
        HttpRequest request = HttpRequest.newBuilder()
                .PUT(HttpRequest.BodyPublishers.noBody())
                .header("Content-Type","application/json")
                .uri(URI.create(osebe_URI + "/" + pacientEmail + "/" + zdravnikEmail))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println(response.body());
    }

    void preglejPacienta(String pacientEmail) throws Exception{
        HttpRequest request = HttpRequest.newBuilder()
                .GET()
                .header("Content-Type","application/json")
                .uri(URI.create(osebe_URI + "/" + pacientEmail))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println(response.body());
    }

    public static void main(String[] args) throws Exception {
        restMain client = new restMain();

        client.dodajOsebo(
                new Pacient("Jaka", "Racman", "Jaka.Racman@lmao.lmao", LocalDate.now(),"", null)
        );

        client.dodajZdravnika("Jaka.Racman@lmao.lmao", "Ana.Novak@lmao.lmao");

        client.vseOsebe();

        System.out.println();

        client.preglejPacienta("Jaka.Racman@lmao.lmao");
    }
}
