package si.um.feri.jee.sample;


import si.um.feri.jee.sample.services.SistemZaDodeljevanjeZdravnikovEJB;

import javax.naming.Context;
import javax.naming.InitialContext;
import java.util.Properties;
import java.util.Scanner;

public class main {

    public static void main(String[] args) throws Exception {
        Scanner s = new Scanner(System.in);

        Properties props=new Properties();
        props.put(Context.INITIAL_CONTEXT_FACTORY, "org.jboss.naming.remote.client.InitialContextFactory");
        props.put(Context.PROVIDER_URL, "http-remoting://127.0.0.1:8080");
        props.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
        InitialContext ctx= new InitialContext(props);

        SistemZaDodeljevanjeZdravnikovEJB sistem = (SistemZaDodeljevanjeZdravnikovEJB)
                ctx.lookup("/AIV/SistemZaDodeljevanjeZdravnikov!si.um.feri.jee.sample.services.SistemZaDodeljevanjeZdravnikovEJB");

        System.out.println("Pacientov e-naslov:");
        String pacientov_email = s.nextLine() + "@lmao.lmao";

        System.out.println("Zdravnikov e-naslov:");
        String zdravnikov_email = s.nextLine() + "@lmao.lmao";

        sistem.najdiObjekta(zdravnikov_email, pacientov_email);

    }

}
