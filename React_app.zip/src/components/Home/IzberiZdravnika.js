import React, { useEffect, useState } from "react";
import { Form } from 'react-bootstrap';

import Api from "../../services/api";


const IzberiZdravnika = (zdravniki) => {


    const email = "Janez.Novak@lmao.lmao    "

    const [izbranZdravnik, setIzbranZdravnik] = useState("");
    const handleLocationChange = (event) => {
        setIzbranZdravnik(event.target.value);
    };



    const handleSubmit = (event) => {

        const zdravnikEmail = izbranZdravnik;
        console.log(zdravnikEmail);
        event.preventDefault();
        //preverim ali sta vnesena username in izbrana lokacija
        

        Api.put(`pacienti/${email}/${zdravnikEmail}`, {
            "email": email,
            "zdravnikovEmail": zdravnikEmail
        })
            .then((result) => { 
                console.log("success" + result.data);
                

            })
            .catch((error) => {
                if (error.response.status === 409) {
                    console.log("409 The request could not be completed due to a conflict with the current state ")
                    alert("THE BUCKET WITH THAT NAME ALREADY EXISTS")
                }
                else if (error.response.status === 400) { console.log("400 Request is badly formatted ") }
                else if(error.response.status == 204 )console.log("jebote riba");
            });

    }



    return(

        <Form onSubmit={handleSubmit}>



        <label>Izberi svojega Zdravnika:
        <select name="location" onChange={handleLocationChange} >
            {zdravniki.zdravniki.map(zdravnik => (
                <option key={zdravnik.id} value={zdravnik.email}>
                    {zdravnik.email}
                </option>
            ))}
        </select>
    </label>
    <input type="submit" />

    </Form>
    );



}

export default IzberiZdravnika;