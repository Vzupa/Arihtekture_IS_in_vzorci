


const ZdravnikiTable = (zdravniki) => {
    console.log(zdravniki);


    return(
        <div>
            <table>
                <thead>
                    <tr>
                        <th>Ime</th>
                        <th>Priimek</th>
                        <th>Email</th>
                        
                    </tr>
                </thead>
                <tbody>
                    {zdravniki.zdravniki.map((pacient) => (
                        <tr key={pacient.id}>
                            <td>{pacient.ime}</td>
                            <td>{pacient.priimek}</td>
                            <td>{pacient.email}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
                            
                            
        </div>
    );

}

export default ZdravnikiTable;