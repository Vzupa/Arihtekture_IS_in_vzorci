import React, { useEffect, useState } from "react";


import Api from "../../services/api"
import ZdravnikiTable from "./ZdravnikiTable";
import IzberiZdravnika from "./IzberiZdravnika";




const Home = () => {

    const [zdravniki, setzdravniki] = useState([]);
    useEffect(() => { //use effect proži se samo ob 1x
        const pridobiPaciente = () => {
            Api.get("/zdravniki").then((result) => { 
                setzdravniki(result.data);
                 console.log(result.data); //prebere uspesno
             })
            .then(() => {
                console.log("Successic!")
                console.log(zdravniki);})
            .catch((error) => {
                console.log("There was an error :-(");
            });
        }
        pridobiPaciente();
    }, []);




    return (
        <div>
            <h1>AIV vaje </h1>
            <ZdravnikiTable zdravniki={zdravniki} />

            <IzberiZdravnika zdravniki={zdravniki}/>
        </div>
    )


}
export default Home